# OTP Bypass Instructions
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

# whatsapp-phishing
the best tool for whatsapp-phishing with otp Bypass ..
![hi](https://user-images.githubusercontent.com/55870659/75668326-29af2900-5c47-11ea-976c-b6263fc96f03.png)

![wh](https://user-images.githubusercontent.com/55870659/76102702-6019da80-5f9e-11ea-9504-14b5de03786b.png)


# Requirements
1. ngrok setup
2. Root - Must
3. Apache Server
4. Internet
5. add repo on kali

# How to Intsall & Use
root ---must !
1. git clone https://github.com/Ignitetch/whatsapp-phishing.git
2. cd whatsapp-phishing
3. chmod 777 Whatsapp.sh
4. ./Whatsapp.sh

# Contact For Contribute
sg5479845@gmail.co
