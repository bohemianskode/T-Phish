#!/bin/bash
#clolors
white='\e[1;37m'
green='\e[0;32m'
blue='\e[1;34m'
red='\e[1;31m'
yellow='\e[1;33m' 
echo ""
echo""
banner() {
	echo -e $'\e[1;33m\e[0m\e[1;37m            "#################################" \e[0m'
	echo -e $'\e[1;33m\e[0m\e[1;37m            "#      ~Advance Phishing~🇮🇩    #" \e[0m'
	echo -e $'\e[1;33m\e[0m\e[1;37m            "#################################" \e[0m'
	echo -e $'\e[1;33m\e[0m\e[1;37m            "#       ~BOHEMIA-VICKY~       #" \e[0m'
	echo -e $'\e[1;33m\e[0m\e[1;37m            "#################################" \e[0m'
   echo ""
   echo -e $'\e[1;33m\e[0m\e[1;33m            [ \e[0m\e[1;32m Cracked by BOHEMIANSKODE \e[0m \e[1;32m\e[0m\e[1;33m ] \e[0m'
   echo ""
      echo -e $'\e[1;37m\e[0m\e[1;37m  -------------------------------------------------------------------\e[0m'
      echo -e $'\e[1;37m\e[0m\e[1;37m  --------------------------- \e[0m'
      }
      b